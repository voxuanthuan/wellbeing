"use strict";
exports.id = 511;
exports.ids = [511];
exports.modules = {

/***/ 2511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "WE": () => (/* binding */ AppStateProvider),
  "bp": () => (/* binding */ useAppContext)
});

// UNUSED EXPORTS: AppContext

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./src/data.js
const QUESTIONS = [{
  id: 0,
  content: 'question1',
  score: undefined
}, {
  id: 1,
  content: 'question2',
  score: undefined
}, {
  id: 2,
  content: 'question3',
  score: undefined
}, {
  id: 3,
  content: 'question4',
  score: undefined
}, {
  id: 4,
  content: 'question5',
  score: undefined
}, {
  id: 5,
  content: 'question6',
  score: undefined
}, {
  id: 6,
  content: 'question7',
  score: undefined
}, {
  id: 7,
  content: 'question8',
  score: undefined
}, {
  id: 8,
  content: 'question9',
  score: undefined
}, {
  id: 9,
  content: 'question10',
  score: undefined
}, {
  id: 10,
  content: 'question11',
  score: undefined
}, {
  id: 11,
  content: 'question12',
  score: undefined
}, {
  id: 12,
  content: 'question13',
  score: undefined
}, {
  id: 13,
  content: 'question14',
  score: undefined
}, {
  id: 14,
  content: 'question15',
  score: undefined
}];
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/context.js



const AppContext = /*#__PURE__*/(0,external_react_.createContext)(undefined);

function AppStateProvider({
  children
}) {
  const {
    0: name,
    1: setName
  } = (0,external_react_.useState)("");
  const {
    0: totalScore,
    1: setTotalScore
  } = (0,external_react_.useState)(0);
  const {
    0: connectScore,
    1: setConnectScore
  } = (0,external_react_.useState)(0);
  const {
    0: takeNoticeScore,
    1: setTakeNoticeScore
  } = (0,external_react_.useState)(0);
  const {
    0: keepLearningScore,
    1: setKeepLearningScore
  } = (0,external_react_.useState)(0);
  const {
    0: beActiveScore,
    1: setBeActiveScore
  } = (0,external_react_.useState)(0);
  const {
    0: giveScore,
    1: setGiveScore
  } = (0,external_react_.useState)(0);
  const {
    0: questions,
    1: setQuestions
  } = (0,external_react_.useState)(QUESTIONS);
  return /*#__PURE__*/jsx_runtime_.jsx(AppContext.Provider, {
    value: {
      name,
      questions,
      totalScore,
      connectScore,
      takeNoticeScore,
      keepLearningScore,
      beActiveScore,
      giveScore,
      setName,
      setQuestions,
      setTotalScore,
      setConnectScore,
      setTakeNoticeScore,
      setKeepLearningScore,
      setBeActiveScore,
      setGiveScore
    },
    children: children
  });
}

function useAppContext() {
  const context = (0,external_react_.useContext)(AppContext);

  if (context === undefined) {
    throw new Error("useAppContext must be used with a AppStateProvider");
  }

  return context;
}



/***/ })

};
;
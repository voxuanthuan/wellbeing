exports.id = 21;
exports.ids = [21];
exports.modules = {

/***/ 9705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Header)
});

;// CONCATENATED MODULE: ./public/BVS_logo.svg
/* harmony default export */ const BVS_logo = ({"src":"/_next/static/image/public/BVS_logo.dbaa33c83157c07172275e672d8d5694.svg","height":33,"width":316});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/Header.js




function Header() {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "h-16 flex items-end pl-16 bg-transparent",
    children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
      href: "/",
      passHref: true,
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "w-[428px] hover:cursor-pointer",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: BVS_logo,
          alt: "BVS Logo"
        })
      })
    })
  });
}

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;
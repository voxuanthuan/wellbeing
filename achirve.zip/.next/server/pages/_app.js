"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 1649:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ MyApp)
});

;// CONCATENATED MODULE: external "i18next"
const external_i18next_namespaceObject = require("i18next");
var external_i18next_default = /*#__PURE__*/__webpack_require__.n(external_i18next_namespaceObject);
// EXTERNAL MODULE: external "react-i18next"
var external_react_i18next_ = __webpack_require__(7789);
;// CONCATENATED MODULE: ./src/locales/en-US/translation.json
const translation_namespaceObject = JSON.parse('{"hi":"Hi, ","amHappie":"I\'m Happie","connect":"Connect","connect-content":"Spend time with people around you - at home, school or in the local community.","be-active":"Be Active","be-active-content":"Exercising makes you feel good. Do an activity you enjoy.","keep-learning":"Keep Learning","keep-learning-content":"Learning isn’t just for school. Study something new or try something different.​.","give":"Give","give-content":"Help other people by being kind, smiling and saying thank you. Do something for others.​","take-notice":"Take Notice","take-notice-content":"Be aware of the world around you and what you are feeling.​​","help":"Help","suffix":"\'s","never":"Never","onceAMonth":"Once a month","onceAWeek":"Once a week","mostDays":"Most days","everyDay":"Every day","question":"How often do you …","question1":"Pay attention to your feelings and emotions?","question2":"Talk with friends either in person or via social media?","question3":"Spend time doing a hobby you like?","question4":"Play sports in a team, like football or netball?","question5":"Volunteer or help in your community, including helping neighbours or friends?","question6":"Help around your home?","question7":"Pay attention to how you are feeling physically, like being full of energy, tired or relaxed?","question8":"Play sports or do exercise not in a team, like running, swimming, or dancing?","question9":" Talk to family you live with about things which matter to you?","question10":"Read for fun?","question11":"Smile and say thank you?","question12":"Talk to family who do not usually live with you, like grandparents, aunts, uncles, and cousins?","question13":"Learn something new for fun?","question14":"Walk or cycle to school or to see friends?","question15":"Notice and enjoy your surroundings?","introDetail":"Here are some simple things to do everyday that can help you to feel <span class=\'text-bvsPeach\'>happier</span> and more <span class=\'text-bvsPeach\'>positive...</span>","beactiveDetail":"Getting <span class=\'text-bvsTeal\'>active</span> can make you feel <span class=\'text-bvsTeal\'>good</span> and keep you <span class=\'text-bvsTeal\'>healthy.</span>","keepLeaningDetail":"Learning isn’t just for school. Study something <span class=\'text-bvsBrightYellow\'>new</span> or try something <span class=\'text-bvsBrightYellow\'>different.</span>","giveDetail":"<span class=\'text-bvsPeach\'>Giving</span> to other people makes both them and you feel special but it’s <span class=\'text-bvsPeach\'>not just about presents.</span>","takeNoticeDetail":"Taking notice means <span class=\'text-bvsDrakTeal\'>understanding</span> feelings, <span class=\'text-bvsDrakTeal\'>watching</span> the world you and <span class=\'text-bvsDrakTeal\'>enjoying</span> life.","connectDetail":"<span class=\'text-bvsPeach\'>Connecting</span> with people can help you, and them, feel <span class=\'text-bvsPeach\'>special</span>. Meeting new people can also make us happy.","whynot":"Why not try some of these...","clickGotHelp":"If you would like some help with your wellbeing or to talk to someone click here","connectInfo":{"talk":"Talk to your friends and family","help":"Help a friend or neighbour","eatMeal":"Eat a meal with your family","makeFriend":"Make a new friend","sayHello":"Say hello","bakeSomeCakes":"Bake some cakes and share them"},"keepLearning":{"keep":"Keep","learning":"Learning","newWord":"Learn a new word each day","artGallery":"Visit a museum or art gallery","musicalInstrument":"Try out a musical instrument","wordSearch":"Do a word search","newFood":"Try a new food","cookRecipe":"Learn to cook a new recipe","animalOrBug":"Study an animal or a bug","newPlace":"Visit a new place","storyOrSong":"Write a story or song"},"beActive":{"danceWithSong":"Dance to your favorite song","walk":"Walk a dog","hulaHoop":"Hula hoop","sportTeams":"Join a sports team","playGames":"Play a game in the playground","walkOrCycle":"Walk or cycle to school","garden":"Help in the garden","raceWithFriends":"Run a race with friends","makeUp":"Make up your own sport"},"takeNoticeInfo":{"Take":"Take","Notice":"Notice","look":"Look what you can see out of your window and how it changes","paint":"Paint or draw a picture of what you\'ve seen today","think":"Think about how you are feeling today","listen":"Listen to the sounds of nature like the wind and rain","play":"Play “I spy”","notice":"Notice how your friends or family are feeling today","lookAt":"Look at the stars"},"giveInfo":{"smile":"Smile and say thank you","make":"Make a homemade present or card for no reason","hold":"Hold a door open for someone","give":"Give someone you love a hug","send":"Send your old toys to a charity shop","share":"Share with others","help":"Help around the house - wash the dishes or do some dusting","listen":"Listen to someone else and how they are feeling"},"wellbeingReport":"Wellbeing Report","overallWellbeing":"Overall Wellbeing","wellbeingTracker":"Wellbeing Tracker","wellbeingChampion":"Wellbeing Champion","doingWell":"Doing Well","makingProcess":"Making Progress","trySomethingNew":"Time To Try Something New","clickToActionPlan":"Click here for your personalised action plan","actionPlanButotn":"action plan","wellbeingActionPlan":"Wellbeing Action plan","topTip":"Wellbeing Buddies’ top tip:","topTipContent":"The best way to really improve wellbeing is through understanding that","importantThing":"‘Wellbeing is important for me’ and ‘There are things that I can do to improve my wellbeing’.","backToReport":"Back to Wellbeing Report","needHelp":"Need help?","learnMore":"Learn more","connectGuideWellBeing":"You are a connect champion, keep doing what you are doing!","beActiveGuideWellBeing":"You are a be active champion, keep doing what you are doing!","keepLearningGuideWellBeing":"You are a keep learning champion, keep doing what you are doing!","givingGuideWellBeing":"You are a giving champion, keep doing what you are doing!","takeNoticeGuideWellBeing":"You are a champion at taking note, keep doing what you are doing!","connectGuideGood":"You are doing well with connecting but make sure you do it every day.","beActiveGuideGood":"You are doing well with being active but make sure you do it every day.","keepLearningGuideGood":"You are doing well with learning new things but make sure you do it every day.","givingGuideGood":"You are doing well with giving but make sure you do it every day.","takeNoticeGuideGood":"You are doing well with taking note but make sure you do it every day.","connectGuideProgress":"Well done for trying to connect but you could do a bit more.","beActiveGuideProgress":"Well done for trying to be active but you could do a bit more. ","keepLearningGuideProgress":"Well done for trying to do some learning outside school but you could do a bit more.","givingGuideProgress":"Well done with your giving but you could do a bit more.","takeNoticeGuideProgress":"Well done for trying to take note but you could do a bit more.","connectGuideTrySomeThing":"Connecting is really important for our wellbeing.","beActiveGuideTrySomeThing":"Being active is really important for our wellbeing.","keepLearningGuideTrySomeThing":"Learning new things is really important for our wellbeing.","givingGuideTrySomeThing":"Giving is really important for our wellbeing.","takeNoticeGuideTrySomeThing":"Taking note is really important for our wellbeing.","aboutWellbeing":"about wellbeing","wellbeingMean":"Wellbeing is about feeling good both mentally and physically.  There are 5 things we can all do to really help our wellbeing","takeQuiz":"take quiz","hintWellbeing":"So how good is you Wellbeing?  Click here to do Wellbeing Buddies’s checkup","weAre":"I\'m Well and </br>We are <span class=\'text-bvsTeal\'>BVIS</span></br><span class=\'text-bvsTeal\'>WellBeing</span>","areFriend":"We are BVIS WellBeing","wellbeingBVSI":"Buddies","next":"Next","back":"Back","submit":"Submit","helpTitle":"If you have any questions or are worried about your wellbeing, there are lots of people you can talk to at BVIS","formTutor":"Your Form Tutor","headOfHouse":"Your Head of House Head of Sixth Form","mrLukeCurran":"<span class=\'font-bold\'>Mr. Luke Curran</span>​​</br> Head of Safeguarding,</br> Welfare and Guidance​","worryBox":"The Student Council​ Worry box​","toHelp":"we are here to help!","bvis":"BVIS","wellbeing":"WELLBEING","campagin":"CAMPAIGN","tips":"Here are some simple things to do everyday that can help you to feel happier and more positive...","scrollDown":"Scroll down for more"}');
;// CONCATENATED MODULE: ./src/locales/vi-VN/translation.json
const vi_VN_translation_namespaceObject = JSON.parse('{"hi":"Xin Chào,","amHappie":"Mình là Happie","connect":"Kết nối","connect-content":"Dành thời gian tương tác với mọi người xung quanh - ở nhà, ở trường hoặc trong cộng đồng.","be-active":"Năng động","be-active-content":"Thể dục thể thao giúp chúng ta cảm thấy thư giãn hơn. Hãy tham gia một hoạt động mà bạn yêu thích.","keep-learning":"Luôn học hỏi","keep-learning-content":"Ngoài việc học và làm, hãy tìm hiểu thêm những kiến thức mới hoặc thử sức với những điều khác biệt.","give":"Chia sẻ","give-content":"Giúp đỡ mọi người bằng sự tử tế, nụ cười và lời cảm ơn. Chia sẻ và hỗ trợ những người xung quanh.​","take-notice":"Quan tâm","take-notice-content":"Quan tâm đến thế giới xung quanh cũng như cảm xúc của chính mình.​​","help":"Giúp đỡ","suffix":"","never":"Không bao giờ","onceAMonth":"Một lần một tháng","onceAWeek":"Một lần một tuần","mostDays":"Hầu hết mỗi ngày","everyDay":"Mỗi ngày","question":"Bạn thường…","question1":"Chú  ý đến cảm nhận và cảm xúc của bản thân?","question2":"Trò chuyện trực tiếp hoặc qua mạng xã hội cùng bạn bè?","question3":"Dành thời gian để làm một việc yêu thích?","question4":"Chơi các môn thể thao đồng đội như bóng đá hoặc bóng rổ? ","question5":"Tham gia tình nguyện hoặc hỗ trợ cộng đồng bao gồm giúp đỡ hàng xóm xung quanh hoặc bạn bè?","question6":"Phụ giúp các công việc nhà?","question7":"Chú ý đến tình trạng sức khỏe thể chất như tràn đầy năng lượng, mệt mỏi hoặc thoải mái?","question8":"Chơi các môn thể thao cá nhân như chạy bộ, bơi lội hoặc nhảy múa? ","question9":"Chia sẻ với gia đình về những vấn đề quan trọng?","question10":"Đọc sách để thư giãn giải trí?","question11":"Nở nụ cười và nói lời cảm ơn?","question12":"Trò chuyện cùng những người thân ở xa như ông bà, cô, chú hoặc anh chị em họ?","question13":"Tìm hiểu những điều mới mẻ để giải trí?","question14":"Đi bộ hoặc đạp xe để đến trường hoặc gặp gỡ bạn bè?","question15":"Quan tâm và tận hưởng môi trường xung quanh?","introDetail":"Sau đây là một số gợi ý mà các em có thể làm hàng ngày để giữ tinh thần <span class=\'text-bvsPeach\'>vui vẻ</span> hơn và <span class=\'text-bvsPeach\'>tích cực</span> hơn...","beactiveDetail":"Trở nên <span class=\'text-bvsTeal\'>Năng động</span> có thể giúp chúng ta <span class=\'text-bvsTeal\'>tích cực</span> và <span class=\'text-bvsTeal\'>khỏe mạnh</span> hơn.","keepLeaningDetail":"Ngoài học tập và làm việc, hãy tìm hiểu thêm những <span class=\'text-bvsBrightYellow\'>kiến thức mới</span> hoặc thử sức với trải nghiệm <span class=\'text-bvsBrightYellow\'>khác biệt.</span>","giveDetail":"Sự <span class=\'text-bvsPeach\'>Chia sẻ</span> giúp người cho và người nhận cảm thấy đặc biệt,  nhưng ý nghĩa <span class=\'text-bvsPeach\'>không chỉ nằm ở những món quà.</span>","takeNoticeDetail":"Sự quan tâm thể hiện rằng bạn  <span class=\'text-bvsDrakTeal\'>thấu hiểu</span> cảm xúc của bản thân và mọi người, cũng như biết <span class=\'text-bvsDrakTeal\'>quan sát</span> thế giới xung quanh và <span class=\'text-bvsDrakTeal\'>trân trọng</span> cuộc sống mà ta đang có.","connectDetail":"<span class=\'text-bvsPeach\'>Kết nối</span> để chúng ta đều cảm thấy mình <span class=\'text-bvsPeach\'>đặc biệt</span>. Đừng ngần ngại kết thêm bạn mới, vì điều đó có thể giúp chúng ta vui vẻ hơn.","whynot":"Hãy thử một số gợi ý sau đây...","clickGotHelp":"Nhấn vào đây để được giúp đỡ tinh thần hoặc liên hệ thành viên BVIS","connectInfo":{"talk":"Trò chuyện với bạn bè hoặc gia đình","help":"Giúp đỡ bạn bè hoặc những người xung quanh","eatMeal":"Cùng ngồi ăn một bữa với các thành viên trong gia đình","makeFriend":"Làm quen thêm bạn mới","sayHello":"Luôn chào hỏi mọi người","bakeSomeCakes":"Làm bánh và chia sẻ với mọi người"},"keepLearning":{"keep":"Luôn","learning":"Học hỏi","newWord":"Học một từ vựng mới hằng ngày","artGallery":"Tham quan một bảo tàng hoặc phòng trưng bày nghệ thuật","musicalInstrument":"Học cách chơi một nhạc cụ","wordSearch":"Chơi một trò chơi thú vị, ví dụ tìm từ","newFood":"Thử một món ăn mới","cookRecipe":"Học một công thức nấu ăn mới","animalOrBug":"Nghiên cứu thêm về một loài động vật hoặc côn trùng","newPlace":"Tham quan một địa danh mới","storyOrSong":"Sáng tác một câu chuyện hoặc bài hát"},"beActive":{"danceWithSong":"Nhảy theo một bài hát yêu thích","walk":"Đi dạo cùng thú cưng","hulaHoop":"Chơi lắc vòng","sportTeams":"Tham gia vào đội nhóm một môn thể thao nào đó","playGames":"Tham gia các hoạt động ở sân chơi","walkOrCycle":"Đi bộ hoặc đạp xe đến trường","garden":"Làm vườn","raceWithFriends":"Chạy đua với bạn bè","makeUp":"Sáng tạo một môn thể thao của riêng mình"},"takeNoticeInfo":{"Take":"Quan","Notice":"Tâm","look":"Ngắm nhìn cuộc sống ngoài ô cửa sổ và quan sát sự thay đổi","paint":"Vẽ một bức tranh mô tả những thứ mình đã quan sát trong một ngày","think":"Suy nghĩ về cảm xúc mà bản thân trải qua trong một ngày","listen":"Lắng nghe âm thanh của thiên nhiên như tiếng gió và mưa","play":"Chơi một trờ chơi thú vị, ví dụ đoán chữ \\"I spy\\"","notice":"Chú ý hơn đến cảm xúc của bạn bè và gia đình ","lookAt":"Ngắm nhìn những vì sao"},"giveInfo":{"smile":"Luôn nở nụ cười và nói lời cảm ơn","make":"Tự tay làm quà tặng hoặc thiệp dành cho người mình yêu quý mà không cần bất kỳ lý do hoặc dịp nào","hold":"Giữ cửa cho người đến sau ","give":"Trao một cái ôm cho người mà bạn yêu quý","send":"Quyên góp đồ chơi cũ cho các hoạt động từ thiện","share":"Chia sẻ với người khác","help":"Giúp đỡ gia đình làm việc nhà – rửa chén hoặc quét nhà","listen":"Lắng nghe người khác và quan tâm đến cảm xúc của họ"},"wellbeingReport":"báo cáo về sức khỏe tinh thần","overallWellbeing":"Tổng quan về Sức khỏe tinh thần","wellbeingTracker":"Theo dõi Sức khỏe Tinh thần","wellbeingChampion":"Sức khỏe tinh thần tuyệt vời","doingWell":"Sức khỏe tinh thần tốt","makingProcess":"Sức khỏe tinh thần đang được cải thiện","trySomethingNew":"Đã đến lúc bạn thử những điều mới mẻ","clickToActionPlan":"Nhấn vào đây để xem kế hoạch cải thiện sức khỏe tinh thần","actionPlanButotn":"Kế hoạch hành động","wellbeingActionPlan":"Kế hoạch </br> hành động tinh thần","topTip":"Gợi ý từ Những người bạn Wellbeing BVIS:     ","topTipContent":"Thấu hiểu \\"Tầm quan trọng của sức khỏe tinh thần\\" và \\"Những giải pháp hữu ích trong tầm tay\\"","importantThing":"sẽ giúp sức khỏe tinh thần cải thiện hiệu quả!","backToReport":"Quay lại báo cáo về sức khỏe tinh thần","needHelp":"Giúp đỡ?","connectGuideWellBeing":"Bạn là nhà vô địch kết nối, hãy giữ sự tích cực này nhé!","beActiveGuideWellBeing":"Bạn là nhà vô địch năng động, hãy giữ sự tích cực này nhé!","keepLearningGuideWellBeing":"Bạn là nhà vô địch học hỏi, hãy giữ sự tích cực này nhé!","givingGuideWellBeing":"Bạn là nhà vô địch chia sẻ, hãy giữ sự tích cực này nhé!","takeNoticeGuideWellBeing":"Bạn là nhà vô địch quan tâm, hãy giữ sự tích cực này nhé!","connectGuideGood":"Bạn kết nối rất tốt, hãy giữ tinh thần này mỗi ngày. ","beActiveGuideGood":"Sự năng động của bạn rất tốt, hãy giữ tinh thần này mỗi ngày.","keepLearningGuideGood":"Bạn có tinh thần học hỏi rất tốt, hãy giữ tinh thần này mỗi ngày.","givingGuideGood":"Bạn rất biết chia sẻ, hãy giữ tinh thần này mỗi ngày.","takeNoticeGuideGood":"Bạn rất biết quan tâm, hãy giữ tinh thần này mỗi ngày.","connectGuideProgress":"Chúc mừng bạn đã cố gắng và bạn có thể kết nối được nhiều hơn nữa.","beActiveGuideProgress":"Chúc mừng bạn đã cố gắng và bạn có thể trở nên năng động hơn nữa.","keepLearningGuideProgress":"Chúc mừng bạn đã cố gắng luôn học hỏi và bạn có thể học thêm nhiều điều hơn nữa.","givingGuideProgress":"Chúc mừng bạn đã cố gắng chia sẻ và bạn có thể làm nhiều hơn thế nữa. ","takeNoticeGuideProgress":"Chúc mừng bạn đã cố gắng và bạn có thể quan tâm nhiều hơn thế nữa.","connectGuideTrySomeThing":"Kết nối là điều thật sự quan trọng đối với tinh thần chúng ta.","beActiveGuideTrySomeThing":"Năng động là điều thật sự quan trọng đối với tinh thần chúng ta.","keepLearningGuideTrySomeThing":"Học hỏi là điều thật sự quan trọng đối với tinh thần chúng ta.","givingGuideTrySomeThing":"Chia sẻ là điều thật sự quan trọng đối với tinh thần chúng ta.","takeNoticeGuideTrySomeThing":"Quan tâm là điều thật sự quan trọng đối với tinh thần chúng ta.","aboutWellbeing":"sức khỏe tinh thần","wellbeingMean":"Một sức khỏe tốt bao gồm sự khỏe mạnh của tinh thần lẫn thể chất. Sau đây là 5 cách giúp chúng ta cải thiện sức khỏe tinh thần","takeQuiz":"Kiểm tra","hintWellbeing":"Sức khỏe tinh thần của bạn đang ở mức độ nào? Hãy nhấn vào đây để tìm hiểu cùng Những người bạn Wellbeing BVIS nhé.","weAre":"Mình là Well. </br>Chúng mình là</br> <span class=\'text-bvsTeal\'>Những người bạn</span></br><span class=\'text-bvsTeal\'>WellBeing</span>","areFriend":" Những người bạn","wellbeingBVSI":"Wellbeing BVIS","next":"Tiếp theo","submit":"Kết Quả","back":"Quay lại","helpTitle":"Mọi thắc mắc hoặc lo lắng về sức khỏe tinh thần của bạn đều được các thành viên BVIS ân cần lắng nghe:","formTutor":"Giáo viên chủ nhiệm","headOfHouse":"Trưởng Đội nhà hoặc Trưởng khối Lớp 12 & 13","mrLukeCurran":"<span class=\'font-bold\'>Thầy Luke Curran</span></br> Trưởng ban Bảo vệ Trẻ em, Tư vấn Tâm lý và Sức khỏe","worryBox":"Worry Box của Hội đồng Học sinh","toHelp":"BVIS luôn sẵn sàng giúp đỡ bạn!","bvis":"BVIS","wellbeing":"Sức khỏe tinh thần","campagin":"Chiến dịch nâng cao","space":"","tips":"Cùng Wellbeing BVIS điểm qua những hoạt động mà các bạn có thể thường xuyên thực hiện để luôn vui vẻ và tích cực!","scrollDown":"Kéo xuống để tìm hiểu thêm"}');
;// CONCATENATED MODULE: ./src/i18n.js



 // the translations
// (tip move them in a JSON file and import them,
// or even better, manage them separated from your code: https://react.i18next.com/guides/multiple-translation-files)

const resources = {
  en: {
    translation: translation_namespaceObject
  },
  vi: {
    translation: vi_VN_translation_namespaceObject
  }
};
external_i18next_default().use(external_react_i18next_.initReactI18next) // passes i18n down to react-i18next
.init({
  resources,
  lng: "en",
  // language to use, more information here: https://www.i18next.com/overview/configuration-options#languages-namespaces-resources
  // you can use the i18n.changeLanguage function to change the language manually: https://www.i18next.com/overview/api#changelanguage
  // if you're using a language detector, do not define the lng option
  fallbackLng: ["en", "vi"],
  interpolation: {
    escapeValue: false // react already safes from xss

  }
});
/* harmony default export */ const src_i18n = ((/* unused pure expression or super */ null && (i18n)));
// EXTERNAL MODULE: ./src/context.js + 1 modules
var context = __webpack_require__(2511);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/Layout.js

function Layout(props) {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "md:container md:mx-auto font-montserrat font-normal",
    children: props.children
  });
}
;// CONCATENATED MODULE: ./src/pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(context/* AppStateProvider */.WE, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Layout, {
      children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
    })
  });
}

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 7789:
/***/ ((module) => {

module.exports = require("react-i18next");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [511], () => (__webpack_exec__(1649)));
module.exports = __webpack_exports__;

})();
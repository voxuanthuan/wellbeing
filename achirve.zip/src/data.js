export const QUESTIONS = [
    {
        id: 0,
        content: 'question1',
        score: undefined,
    },
    {
        id: 1,
        content: 'question2',
        score: undefined,
    },
    {
        id: 2,
        content: 'question3',
        score: undefined,
    },
    {
        id: 3,
        content: 'question4',
        score: undefined,
    },
    {
        id: 4,
        content: 'question5',
        score: undefined,
    },
    {
        id: 5,
        content: 'question6',
        score: undefined,
    },
    {
        id: 6,
        content: 'question7',
        score: undefined,
    },
    {
        id: 7,
        content: 'question8',
        score: undefined,
    },
    {
        id: 8,
        content: 'question9',
        score: undefined,
    },
    {
        id: 9,
        content: 'question10',
        score: undefined,
    },
    {
        id: 10,
        content: 'question11',
        score: undefined,
    },
    {
        id: 11,
        content: 'question12',
        score: undefined,
    },
    {
        id: 12,
        content: 'question13',
        score: undefined,
    },
    {
        id: 13,
        content: 'question14',
        score: undefined,
    },
    {
        id: 14,
        content: 'question15',
        score: undefined,
    },
]
